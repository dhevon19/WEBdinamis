#Project Web dinamis Produktif tkj

Project PHP Native Simple yang dipergunakan untuk mengolah datasiswa, dan berikut persiapan client untuk installasi apps. 

===========================================================================

terimakasih banyak atas perhatiannya.
- OmTegar 

===========================================================================

Langkah Langkah Proses installasi:

1. Lakukan installasi Xampp pada PC anda ( https://www.filehorse.com/download-xampp-portable/74764/?amp )
2. install git pada pc anda ( https://gitforwindows.org/ )
3. Lakukan Config global <br>
<code>git config --global user.name "username"
git config --global user.email example@example.com</code>
4. Buka File Explorer dan pindah pada Directory C:\xampp\htdocs\ 
5. Clonning repository dengan cara : git clone ( https://github.com/OmTegar/Web-Dinamis-Produktif.git )
6. Masuk Ke Directory \Web-Dinamis-Produktif dan buka di text editor kalian.
7. Buka App Xampp dan running Apache dan MySQL.
8. Buka PHPMyAdmin di Browser dengan mengetikan ( http://localhost/phpmyadmin/index.php?route=/server/databases ) 
9. Buat Database Baru Dengan Nama ( datasiswa ) , buka Db:datasiswa dan import file di MySQL di folder ( \Web-Dinamis-Produktif\asset\database\datasiswa.sql )
10. App Sudah Siap Di Running dengan cara ketik Link dari app yaitu ( http://localhost/Web-Dinamis-Produktif/ )

===========================================================================
